<?php
require __DIR__ . '/includes/auth.php';

log_activity('Sign out', 'Authentication', '');
clear_remember_cookie();
$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

header('Location: index.php');
exit;
